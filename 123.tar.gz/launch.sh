exec sxhkd &
nitrogen --restore &
NetworkManager &
polybar &


#nm-applet &
#xfce4-panel &
