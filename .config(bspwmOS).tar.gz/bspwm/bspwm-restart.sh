/home/test/.config/bspwm/bspwmrc
