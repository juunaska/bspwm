#polybar &
#exec /usr/bin/NetworkManager --no-daemon &


NetworkManager &
exec sxhkd &
nitrogen --restore &
tint2 &
pnmixer &
cbatticon &
nm-applet &
volumeicon &
#lxpanel & 
#xfce4-panel &
#picom & 
